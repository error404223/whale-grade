import { activities, type Activity, type InsertActivity } from "@shared/schema";

export interface IStorage {
  getActivity(id: number): Promise<Activity | undefined>;
  getActivityByName(activityName: string): Promise<Activity | undefined>;
  createActivity(activity: InsertActivity): Promise<Activity>;
  getAllActivities(): Promise<Activity[]>;
}

export class MemStorage implements IStorage {
  private activities: Map<number, Activity>;
  private currentId: number;

  constructor() {
    this.activities = new Map();
    this.currentId = 1;
  }

  async getActivity(id: number): Promise<Activity | undefined> {
    return this.activities.get(id);
  }

  async getActivityByName(activityName: string): Promise<Activity | undefined> {
    return Array.from(this.activities.values()).find(
      (activity) => activity.activityName.toLowerCase() === activityName.toLowerCase(),
    );
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentId++;
    const activity: Activity = { 
      ...insertActivity, 
      id,
      createdAt: new Date()
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getAllActivities(): Promise<Activity[]> {
    return Array.from(this.activities.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();
