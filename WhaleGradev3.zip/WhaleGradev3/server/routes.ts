import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { assessActivitySchema, type WhaleGradeResponse } from "@shared/schema";
import { calculateWhaleGrade } from "./ai-assessment";

export async function registerRoutes(app: Express): Promise<Server> {
  // Assess activity endpoint
  app.post("/api/assess-activity", async (req, res) => {
    try {
      const { activity } = assessActivitySchema.parse(req.body);
      
      // Check if we already have this activity cached
      const existingActivity = await storage.getActivityByName(activity);
      if (existingActivity) {
        const response: WhaleGradeResponse = {
          score: existingActivity.whaleGrade,
          safetyRating: existingActivity.safetyRating as any,
          explanation: existingActivity.explanation,
          activityName: existingActivity.activityName
        };
        return res.json(response);
      }

      // Calculate new whale grade using OpenAI
      const result = await calculateWhaleGrade(activity);
      
      // Store the result
      const savedActivity = await storage.createActivity({
        activityName: activity,
        whaleGrade: result.score,
        safetyRating: result.safetyRating,
        explanation: result.explanation
      });

      const response: WhaleGradeResponse = {
        score: result.score,
        safetyRating: result.safetyRating,
        explanation: result.explanation,
        activityName: activity
      };

      res.json(response);
    } catch (error) {
      console.error("Error assessing activity:", error);
      if (error instanceof Error) {
        res.status(400).json({ message: error.message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  // Get recent activities
  app.get("/api/activities", async (req, res) => {
    try {
      const activities = await storage.getAllActivities();
      res.json(activities.slice(0, 10)); // Return last 10 activities
    } catch (error) {
      console.error("Error fetching activities:", error);
      res.status(500).json({ message: "Failed to fetch activities" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
