import { HfInference } from '@huggingface/inference';

const hf = new HfInference();

export interface WhaleGradeResult {
  score: number;
  safetyRating: "Safe" | "Moderate Safe" | "Less Safe" | "Dangerous" | "Extremely Dangerous";
  explanation: string;
}

// Check for truly dangerous illegal activities (not just inappropriate)
function isDangerousIllegalActivity(activity: string): boolean {
  const activityLower = activity.toLowerCase().trim();

  const dangerousIllegalActivities = [
    'murder', 'killing', 'homicide', 'manslaughter', 'rape', 'sexual assault', 
    'kidnapping', 'terrorism', 'bomb', 'explosive', 'arson', 'poison',
    'drug trafficking', 'weapons trafficking', 'human trafficking'
  ];

  return dangerousIllegalActivities.some(term => activityLower.includes(term));
}

// Check for inappropriate but not dangerous content
function isInappropriateContent(activity: string): boolean {
  const activityLower = activity.toLowerCase().trim();

  const inappropriateTerms = [
    'porn', 'pornography', 'masturbation', 'explicit content', 'nsfw', 'erotic'
  ];

  return inappropriateTerms.some(term => activityLower.includes(term));
}

export async function calculateWhaleGrade(activity: string): Promise<WhaleGradeResult> {
  console.log(`Analyzing activity: ${activity}`);

  // Handle inappropriate content separately (not as dangerous)
  if (isInappropriateContent(activity)) {
    return {
      score: 50, // Neutral score, not dangerous
      safetyRating: "Moderate Safe",
      explanation: "This request contains inappropriate content that cannot be fully assessed. Please enter a family-friendly activity for a complete safety evaluation."
    };
  }

  // Only flag truly dangerous illegal activities as extremely dangerous
  if (isDangerousIllegalActivity(activity)) {
    return {
      score: 5,
      safetyRating: "Extremely Dangerous",
      explanation: "This activity involves serious criminal behavior with extreme physical danger and severe legal consequences. Such activities pose immediate threats to safety and well-being."
    };
  }

  try {
    // Enhanced AI prompt for better responses
    const prompt = `Analyze the safety of "${activity}" considering:
1. Injury statistics and fatality rates
2. Required safety equipment and education
3. Environmental hazards and risk factors
4. Participant experience requirements
5. Emergency response accessibility

Provide a safety score from 1-10 (10 = safest) and specific safety considerations for ${activity}.

Activity: ${activity}
Safety Analysis:`;

    const response = await hf.textGeneration({
      model: 'microsoft/DialoGPT-medium',
      inputs: prompt,
      parameters: {
        max_new_tokens: 200,
        temperature: 0.6,
        return_full_text: false,
      },
    });

    console.log('AI Response received');

    // Extract score and generate intelligent analysis
    let score10 = extractScoreFromResponse(response.generated_text) || calculateIntelligentScore(activity);
    score10 = Math.max(1, Math.min(10, score10));

    // Apply danger logic analysis
    score10 = applyDangerLogic(activity, score10);

    // Convert to 100-point scale
    const score100 = convertTo100ScaleWithCurve(score10, activity);

    // Determine safety rating
    let safetyRating: "Safe" | "Moderate Safe" | "Less Safe" | "Dangerous" | "Extremely Dangerous";
    if (score100 >= 75) safetyRating = "Safe";
    else if (score100 >= 55) safetyRating = "Moderate Safe";
    else if (score100 >= 35) safetyRating = "Less Safe";
    else if (score100 >= 20) safetyRating = "Dangerous";
    else safetyRating = "Extremely Dangerous";

    // Generate detailed, activity-specific explanation
    const explanation = generateActivitySpecificExplanation(activity, score100, safetyRating);

    return {
      score: Math.round(score100),
      safetyRating,
      explanation
    };

  } catch (error) {
    console.log("Using intelligent assessment system");
    return calculateIntelligentWhaleGrade(activity);
  }
}

function generateActivitySpecificExplanation(activity: string, score: number, rating: string): string {
  const activityCap = activity.charAt(0).toUpperCase() + activity.slice(1);
  const analysis = parseActivity(activity);
  
  // Generate detailed explanation based on the enhanced activity analysis
  let explanation = generateBaseActivityExplanation(analysis, score);
  
  // Add modifier-specific insights
  if (analysis.modifiers.length > 0) {
    explanation += ` ${generateModifierInsights(analysis.modifiers, score)}`;
  }
  
  // Add context-specific warnings
  if (analysis.context.length > 0) {
    explanation += ` ${generateContextWarnings(analysis.context)}`;
  }
  
  // Add legal status check
  const legalWarning = checkLegalStatus(activity);
  if (legalWarning) {
    explanation += ` ${legalWarning}`;
  }
  
  // Add statistical context based on score
  explanation += ` ${generateStatisticalContext(analysis.baseActivity, score)}`;
  
  return explanation;
}

function generateBaseActivityExplanation(analysis: ActivityAnalysis, score: number): string {
  // Generate unique, context-aware analysis based on the specific activity
  const uniqueAnalysis = generateUniqueActivityAnalysis(analysis, score);
  
  return uniqueAnalysis;
}

function generateUniqueActivityAnalysis(analysis: ActivityAnalysis, score: number): string {
  // Create a unique seed based on activity characteristics for consistent but varied output
  const activitySeed = createActivitySeed(analysis);
  
  const specificRisks = identifySpecificRisks(analysis, activitySeed);
  const safetyMeasures = generateSpecificSafetyMeasures(analysis, score, activitySeed);
  const statisticalInsight = generateStatisticalInsight(analysis, score, activitySeed);
  const environmentalFactors = analyzeEnvironmentalFactors(analysis);
  const equipmentAnalysis = generateEquipmentAnalysis(analysis, score, activitySeed);
  const experienceFactors = analyzeExperienceRequirements(analysis, score, activitySeed);
  
  // Create a unique analysis structure based on activity type and risk level
  let analysis_text = `${generateActivityDescription(analysis, score, activitySeed)} `;
  
  // Add dynamic content based on activity characteristics
  if (score < 50) {
    // High-risk activities get more detailed risk analysis
    analysis_text += `${generateRiskAssessment(analysis, score, activitySeed)} `;
    if (specificRisks.length > 0) {
      analysis_text += `Critical risk factors include ${specificRisks.slice(0, 4).join(', ')}. `;
    }
    analysis_text += `${experienceFactors} `;
  } else if (score < 75) {
    // Moderate-risk activities focus on preparation
    if (specificRisks.length > 0) {
      analysis_text += `Key risk considerations include ${specificRisks.slice(0, 3).join(', ')}. `;
    }
    analysis_text += `${safetyMeasures} `;
  } else {
    // Low-risk activities emphasize positive aspects
    analysis_text += `${generatePositiveAspects(analysis, activitySeed)} `;
    if (specificRisks.length > 0) {
      analysis_text += `Minor considerations include ${specificRisks.slice(0, 2).join(' and ')}. `;
    }
  }
  
  // Add equipment analysis if relevant
  if (equipmentAnalysis) {
    analysis_text += `${equipmentAnalysis} `;
  }
  
  // Add environmental considerations if applicable
  if (environmentalFactors) {
    analysis_text += `${environmentalFactors} `;
  }
  
  // Add statistical context
  analysis_text += `${statisticalInsight}`;
  
  return analysis_text;
}

function createActivitySeed(analysis: ActivityAnalysis): number {
  // Create a pseudo-random seed based on activity characteristics
  let seed = 0;
  for (let i = 0; i < analysis.baseActivity.length; i++) {
    seed += analysis.baseActivity.charCodeAt(i);
  }
  seed += analysis.modifiers.length * 7;
  seed += analysis.context.length * 13;
  seed += analysis.riskFactors.length * 19;
  return seed % 1000;
}

function generateRiskAssessment(analysis: ActivityAnalysis, score: number, seed: number): string {
  const riskAssessments = [
    'Comprehensive risk evaluation reveals multiple safety concerns requiring immediate attention',
    'Safety analysis indicates elevated danger levels across several risk categories',
    'Risk assessment demonstrates significant hazard potential in various operational scenarios',
    'Detailed safety evaluation highlights numerous factors contributing to increased danger levels'
  ];
  
  return riskAssessments[seed % riskAssessments.length];
}

function generatePositiveAspects(analysis: ActivityAnalysis, seed: number): string {
  const positiveAspects = [
    'This activity demonstrates excellent safety characteristics with well-established protective measures',
    'Safety analysis reveals favorable risk-to-benefit ratios with minimal serious injury potential',
    'Research indicates strong safety outcomes when basic precautionary measures are observed',
    'Statistical evidence supports the low-risk classification with consistent positive safety trends'
  ];
  
  return positiveAspects[seed % positiveAspects.length];
}

function generateEquipmentAnalysis(analysis: ActivityAnalysis, score: number, seed: number): string | null {
  // Only generate equipment analysis for relevant activities
  const equipmentRelevantCategories = ['extreme_sports', 'water_sports', 'winter_sports', 'transportation', 'combat_sports'];
  
  if (!equipmentRelevantCategories.includes(analysis.category)) {
    return null;
  }
  
  const equipmentAnalyses = [
    'Equipment reliability and proper maintenance play crucial roles in safety outcomes',
    'Safety equipment standards and certification requirements significantly impact risk levels',
    'Proper gear selection and regular equipment inspection are fundamental safety requirements',
    'Advanced safety equipment and backup systems provide essential protection against equipment failure'
  ];
  
  // Add equipment-specific modifiers
  if (analysis.modifiers.some(m => m.includes('without') || m.includes('faulty'))) {
    return 'Inadequate or compromised equipment substantially increases danger levels beyond acceptable parameters';
  }
  
  return equipmentAnalyses[seed % equipmentAnalyses.length];
}

function analyzeExperienceRequirements(analysis: ActivityAnalysis, score: number, seed: number): string {
  const experienceAnalyses = {
    beginner: [
      'Novice participants face significantly elevated risks due to inexperience and unfamiliarity with safety protocols',
      'Beginning practitioners require extensive supervision and gradual skill development to minimize injury potential',
      'Entry-level participation demands comprehensive education and controlled practice environments'
    ],
    intermediate: [
      'Moderate experience levels require continued skill development and advanced safety training',
      'Participants with basic skills benefit from progressive challenge increases and mentorship',
      'Intermediate practitioners should focus on technique refinement and risk management skills'
    ],
    advanced: [
      'Experienced practitioners demonstrate lower injury rates through developed skills and safety awareness',
      'Advanced participants benefit from their accumulated knowledge and refined risk assessment abilities',
      'Expert-level practitioners maintain safety through continuous skill maintenance and updated training'
    ]
  };
  
  let experienceLevel: keyof typeof experienceAnalyses;
  if (analysis.modifiers.some(m => m.includes('amateur') || m.includes('first time'))) {
    experienceLevel = 'beginner';
  } else if (analysis.modifiers.some(m => m.includes('professional') || m.includes('expert'))) {
    experienceLevel = 'advanced';
  } else {
    experienceLevel = 'intermediate';
  }
  
  const options = experienceAnalyses[experienceLevel];
  return options[seed % options.length];
}

function generateActivityDescription(analysis: ActivityAnalysis, score: number, seed: number): string {
  const activityName = analysis.baseActivity.replace('_', ' ');
  const descriptions = {
    high_risk: [
      `${activityName} is classified as a high-risk activity requiring extensive safety preparation`,
      `Participating in ${activityName} involves significant physical and environmental challenges`,
      `${activityName} demands advanced skill levels and comprehensive risk assessment`
    ],
    moderate_risk: [
      `${activityName} presents manageable risks with proper preparation and awareness`,
      `This ${analysis.category.replace('_', ' ')} activity has moderate safety considerations`,
      `${activityName} requires standard safety protocols and basic skill development`
    ],
    low_risk: [
      `${activityName} is generally considered a safe activity with minimal injury risk`,
      `This ${analysis.category.replace('_', ' ')} activity has excellent safety statistics`,
      `${activityName} poses minimal physical danger when performed correctly`
    ]
  };

  const riskLevel = score >= 70 ? 'low_risk' : score >= 45 ? 'moderate_risk' : 'high_risk';
  const options = descriptions[riskLevel];
  
  // Use seed for consistent but varied selection
  const selectedDescription = options[seed % options.length];
  return selectedDescription;
}

function identifySpecificRisks(analysis: ActivityAnalysis, seed: number): string[] {
  const risks: string[] = [];
  
  // Category-specific risks
  const categoryRisks = {
    extreme_sports: ['equipment failure', 'human error', 'environmental conditions', 'emergency response limitations'],
    water_sports: ['drowning', 'hypothermia', 'water quality', 'weather conditions', 'equipment malfunction'],
    winter_sports: ['avalanche risk', 'hypothermia', 'visibility issues', 'equipment failure', 'slope conditions'],
    transportation: ['mechanical failure', 'operator error', 'traffic conditions', 'weather hazards'],
    combat_sports: ['traumatic brain injury', 'joint damage', 'cardiovascular stress', 'improper technique'],
    daily_activities: ['repetitive strain', 'cuts and burns', 'falls', 'improper technique'],
    outdoor_activities: ['wildlife encounters', 'weather exposure', 'navigation errors', 'equipment failure']
  };

  // Add category-specific risks
  const catRisks = categoryRisks[analysis.category as keyof typeof categoryRisks] || ['general injury risk'];
  const numRisks = 2 + (seed % 3); // 2-4 risks based on seed
  risks.push(...catRisks.slice(0, numRisks));

  // Add modifier-specific risks
  if (analysis.modifiers.some(m => m.includes('amateur') || m.includes('untrained'))) {
    risks.push('lack of experience', 'improper technique');
  }
  if (analysis.modifiers.some(m => m.includes('solo') || m.includes('unguided'))) {
    risks.push('absence of supervision', 'emergency response delays');
  }
  if (analysis.modifiers.some(m => m.includes('diy') || m.includes('homemade'))) {
    risks.push('equipment reliability issues', 'safety standard violations');
  }

  return Array.from(new Set(risks)); // Remove duplicates
}

function generateSpecificSafetyMeasures(analysis: ActivityAnalysis, score: number, seed: number): string {
  const measures: string[] = [];
  
  // Score-based safety recommendations
  if (score >= 75) {
    measures.push('basic safety awareness', 'following standard guidelines');
  } else if (score >= 55) {
    measures.push('comprehensive safety training', 'proper equipment inspection', 'weather monitoring');
  } else if (score >= 35) {
    measures.push('expert instruction', 'specialized safety equipment', 'emergency action planning');
  } else {
    measures.push('extensive professional training', 'redundant safety systems', 'expert supervision');
  }

  // Category-specific measures
  const categoryMeasures = {
    extreme_sports: ['equipment redundancy', 'weather assessment', 'emergency communication'],
    water_sports: ['swimming proficiency', 'flotation devices', 'buddy system'],
    winter_sports: ['avalanche safety training', 'appropriate clothing', 'slope condition assessment'],
    transportation: ['defensive techniques', 'vehicle maintenance', 'route planning'],
    combat_sports: ['protective equipment', 'medical clearance', 'referee supervision']
  };

  const catMeasures = categoryMeasures[analysis.category as keyof typeof categoryMeasures] || [];
  measures.push(...catMeasures);

  // Create unique safety recommendation based on seed
  const numMeasures = 3 + (seed % 3); // 3-5 measures based on seed
  const selectedMeasures = measures.slice(0, numMeasures);
  return `Essential safety measures include ${selectedMeasures.join(', ')}.`;
}

function analyzeEnvironmentalFactors(analysis: ActivityAnalysis): string | null {
  if (analysis.context.length === 0) return null;
  
  const contextAnalysis: string[] = [];
  
  analysis.context.forEach(context => {
    switch (context) {
      case 'high altitude':
        contextAnalysis.push('altitude sickness risks and reduced oxygen levels');
        break;
      case 'underwater':
        contextAnalysis.push('decompression sickness and breathing apparatus dependency');
        break;
      case 'in storm':
        contextAnalysis.push('severe weather hazards and visibility limitations');
        break;
      case 'at night':
        contextAnalysis.push('reduced visibility and navigation challenges');
        break;
      case 'remote area':
        contextAnalysis.push('limited emergency response access and communication challenges');
        break;
    }
  });

  if (contextAnalysis.length > 0) {
    return `Environmental considerations include ${contextAnalysis.join(', ')}.`;
  }
  
  return null;
}

function generateStatisticalInsight(analysis: ActivityAnalysis, score: number, seed: number): string {
  const insights = [
    // High safety scores
    ...(score >= 80 ? [
      'Safety statistics demonstrate consistently low injury rates across participant demographics.',
      'Long-term studies show minimal serious adverse outcomes when standard protocols are followed.',
      'Injury severity data indicates predominantly minor incidents with full recovery expectations.'
    ] : []),
    
    // Moderate safety scores  
    ...(score >= 50 && score < 80 ? [
      'Injury statistics show manageable risk levels with proper preparation and technique.',
      'Safety outcomes improve significantly with experience and proper training.',
      'Most incidents are preventable through awareness and appropriate safety measures.'
    ] : []),
    
    // Low safety scores
    ...(score < 50 ? [
      'Statistical analysis reveals elevated injury rates requiring serious risk consideration.',
      'Safety data indicates significant potential for serious harm even with precautions.',
      'Incident reports show consistent patterns of severe injuries across experience levels.'
    ] : [])
  ];

  // Add activity-specific statistical elements
  const activityStats = {
    'base jumping': 'with fatality rates significantly higher than other extreme sports',
    'driving': 'with accident rates varying substantially by location and conditions',
    'swimming': 'with drowning statistics concentrated in unsupervised environments',
    'cooking': 'with injury patterns primarily involving cuts and thermal burns'
  };

  let insight = insights[seed % insights.length];
  
  const activityStat = activityStats[analysis.baseActivity as keyof typeof activityStats];
  if (activityStat) {
    insight += ` ${activityStat}`;
  }

  return insight;
}

function getCategorySpecificInsights(category: string, baseActivity: string, score: number): Record<string, string> {
  const insights = {
    extreme_sports: {
      safe: "This extreme sport has established safety protocols that, when followed, result in relatively low serious injury rates.",
      moderatelySafe: "While inherently high-risk, proper training and equipment significantly reduce accident rates.",
      caution: "This activity carries substantial risks that require extensive preparation and risk acceptance.",
      dangerous: "Extreme danger levels with documented fatalities even among experienced participants.",
      extremelyDangerous: "Life-threatening activity with exceptionally high fatality rates per participant."
    },
    water_sports: {
      safe: "Water-based activity with good safety record when proper swimming ability and awareness are maintained.",
      moderatelySafe: "Drowning and water-related injuries are manageable risks with appropriate safety measures.",
      caution: "Significant water hazards including drowning, hypothermia, and environmental dangers require careful planning.",
      dangerous: "High drowning risk and water-related dangers make this activity hazardous for most participants.",
      extremelyDangerous: "Extreme water dangers with limited rescue possibilities pose life-threatening risks."
    },
    winter_sports: {
      safe: "Winter activity with manageable cold-weather and terrain risks through proper equipment and technique.",
      moderatelySafe: "Moderate injury rates from falls and collisions, controlled through skill development and safety awareness.",
      caution: "Cold weather, terrain hazards, and high-speed risks require comprehensive safety preparation.",
      dangerous: "Significant risks from weather exposure, avalanches, and high-impact injuries.",
      extremelyDangerous: "Extreme winter conditions and terrain create life-threatening scenarios."
    },
    transportation: {
      safe: "Transportation method with established safety systems and regulatory oversight providing good protection.",
      moderatelySafe: "Well-documented safety statistics with manageable risks through defensive practices and maintenance.",
      caution: "Collision and mechanical risks require vigilant operation and regular safety maintenance.",
      dangerous: "High accident rates and potential for serious injury demand expert-level operation skills.",
      extremelyDangerous: "Extremely dangerous transportation method with very high fatality rates."
    },
    combat_sports: {
      safe: "Controlled combat activity with protective equipment and medical oversight minimizing serious injuries.",
      moderatelySafe: "Contact sport with moderate concussion and injury risks managed through proper protection and rules.",
      caution: "Significant risk of traumatic injuries including concussions requiring medical clearance and protective gear.",
      dangerous: "High risk of serious traumatic brain injury and long-term neurological damage.",
      extremelyDangerous: "Extreme violence with near-certain serious injury or permanent damage."
    },
    daily_activities: {
      safe: "Routine activity with minimal physical risks and well-established safety practices.",
      moderatelySafe: "Common activity with low injury rates and manageable household hazards.",
      caution: "Even routine activities can present unexpected risks requiring basic safety awareness.",
      dangerous: "Unusually hazardous version of common activity requiring special precautions.",
      extremelyDangerous: "Extremely dangerous modification of routine activity."
    }
  };

  return insights[category as keyof typeof insights] || {
    safe: "Activity demonstrates favorable safety statistics with proper precautions.",
    moderatelySafe: "Moderate risk activity manageable through awareness and preparation.",
    caution: "Elevated risk activity requiring careful assessment and safety measures.",
    dangerous: "High-risk activity with significant potential for serious harm.",
    extremelyDangerous: "Extremely dangerous activity with severe consequences likely."
  };
}

function getActivitySpecificDetails(baseActivity: string) {
  const activityDetails = {
    // Extreme sports
    'base jumping': {
      description: "Base jumping involves parachuting from fixed objects and has one of the highest fatality rates in extreme sports.",
      safePractices: "Requires extensive skydiving experience, specialized equipment, and ideal weather conditions.",
      standardPrecautions: "Mandatory safety equipment includes specially designed parachutes and protective gear.",
      riskMitigation: "Comprehensive training programs and experienced mentorship are essential for risk reduction.",
      expertRequired: "Only recommended for expert-level participants with extensive parachuting background.",
      notRecommended: "Extremely high fatality rate makes this inadvisable for most people."
    },
    'skydiving': {
      description: "Skydiving is a regulated extreme sport with established safety protocols and equipment standards.",
      safePractices: "Tandem jumps with certified instructors provide the safest introduction to the sport.",
      standardPrecautions: "Proper training, equipment inspection, and weather assessment are standard safety measures.",
      riskMitigation: "Automated activation devices and dual parachute systems significantly reduce equipment failure risks.",
      expertRequired: "Solo jumping requires extensive training and certification processes.",
      notRecommended: "While statistically safer than many extreme sports, inherent risks remain significant."
    },
    'driving': {
      description: "Motor vehicle operation is a common transportation method with well-documented safety statistics.",
      safePractices: "Defensive driving techniques, seat belt use, and vehicle maintenance ensure optimal safety.",
      standardPrecautions: "Following traffic laws, avoiding distractions, and regular vehicle inspections reduce risks.",
      riskMitigation: "Modern safety features like airbags, ABS, and collision avoidance systems improve outcomes.",
      expertRequired: "High-performance or commercial driving requires specialized training and licensing.",
      notRecommended: "Reckless or impaired driving dramatically increases accident probability."
    },
    'swimming': {
      description: "Swimming is a popular recreational and fitness activity with manageable drowning risks.",
      safePractices: "Proper swimming instruction and supervised environments provide excellent safety foundations.",
      standardPrecautions: "Never swimming alone, understanding water conditions, and staying within abilities are key.",
      riskMitigation: "Lifeguard supervision, flotation devices, and emergency action plans reduce drowning risks.",
      expertRequired: "Open water and distance swimming require advanced skills and safety planning.",
      notRecommended: "Swimming in dangerous conditions or without proper skills creates unnecessary risks."
    },
    'cooking': {
      description: "Food preparation is a daily activity with minor burn and cut risks that are easily preventable.",
      safePractices: "Proper knife handling, heat awareness, and kitchen organization minimize injury risks.",
      standardPrecautions: "Using appropriate tools, maintaining clean surfaces, and following food safety guidelines.",
      riskMitigation: "First aid knowledge and proper equipment storage reduce accident severity.",
      expertRequired: "Professional cooking involves specialized equipment requiring additional safety training.",
      notRecommended: "Cooking under impairment or with faulty equipment increases accident likelihood."
    }
  };

  return activityDetails[baseActivity as keyof typeof activityDetails] || {
    description: `${baseActivity.replace('_', ' ')} is an activity with specific risk factors that vary based on implementation.`,
    safePractices: "Following established safety guidelines and using appropriate equipment when available.",
    standardPrecautions: "Basic safety awareness and risk assessment help prevent most common injuries.",
    riskMitigation: "Proper training and gradual skill development reduce accident probability.",
    expertRequired: "Advanced versions require specialized knowledge and safety preparations.",
    notRecommended: "Improper execution or inadequate preparation significantly increases risks."
  };
}

function generateModifierInsights(modifiers: string[], score: number): string {
  const riskIncreasing = modifiers.filter(m => 
    ['amateur', 'untrained', 'without safety', 'first time', 'solo', 'diy', 'homemade'].includes(m)
  );
  
  const riskDecreasing = modifiers.filter(m => 
    ['professional', 'supervised', 'with instructor', 'certified', 'licensed'].includes(m)
  );

  if (riskIncreasing.length > 0) {
    return `The ${riskIncreasing.join(', ')} nature significantly increases danger levels beyond normal risk parameters.`;
  } else if (riskDecreasing.length > 0) {
    return `${riskDecreasing.join(' and ')} supervision/certification provides additional safety benefits.`;
  }
  
  return '';
}

function generateContextWarnings(context: string[]): string {
  const dangerousContexts = context.filter(c => 
    ['high altitude', 'underwater', 'in storm', 'at night', 'remote area'].includes(c)
  );
  
  if (dangerousContexts.length > 0) {
    return `Environmental factors including ${dangerousContexts.join(', ')} create additional hazards requiring specialized preparation.`;
  }
  
  return '';
}

function checkLegalStatus(activity: string): string {
  const activityLower = activity.toLowerCase();
  const illegalActivities = [
    'murder', 'killing', 'homicide', 'manslaughter', 'rape', 'sexual assault', 'kidnapping', 'terrorism',
    'drug trafficking', 'robbery', 'burglary', 'drunk driving', 'weapons trafficking', 'theft', 'fraud',
    'arson', 'assault', 'battery', 'extortion', 'money laundering', 'embezzlement'
  ];

  const isIllegal = illegalActivities.some(illegal => activityLower.includes(illegal));
  return isIllegal ? 'This activity involves serious legal consequences including potential criminal charges and imprisonment.' : '';
}

function generateStatisticalContext(baseActivity: string, score: number): string {
  const statistics: Record<string, string> = {
    'base jumping': "Fatality rate: approximately 1 in 2,300 participants annually.",
    'wingsuit flying': "Fatality rate: approximately 1 in 900 participants annually.",
    'skydiving': "Fatality rate: approximately 1 in 100,000 jumps with modern safety equipment.",
    'driving': "Annual fatality rate: approximately 1.33 deaths per 100 million vehicle miles traveled.",
    'swimming': "Drowning accounts for approximately 360,000 deaths globally per year.",
    'cooking': "Kitchen accidents result in approximately 165,000 emergency room visits annually in the US."
  };

  return statistics[baseActivity] || 
    (score >= 85 ? "Statistical analysis shows very low serious injury rates." :
     score >= 70 ? "Injury rates are manageable with proper precautions." :
     score >= 55 ? "Moderate injury rates require safety awareness." :
     score >= 40 ? "Elevated injury and fatality statistics documented." :
     "High injury and fatality rates per participant documented.");
}

function isMainstreamActivity(activity: string): boolean {
  // Enhanced mainstream activities with comprehensive pattern matching
  const mainstreamActivities = {
    // Ultra-high participation (>100 million participants globally)
    'walking': {
      participants: 1000000000,
      patterns: ['walking', 'walk', 'stroll', 'pedestrian', 'hiking', 'trekking', 'ramble', 'march']
    },
    'driving': {
      participants: 800000000,
      patterns: ['driving', 'drive', 'car', 'automobile', 'vehicle', 'motoring', 'commuting']
    },
    'cooking': {
      participants: 500000000,
      patterns: ['cooking', 'cook', 'baking', 'bake', 'kitchen', 'culinary', 'food prep', 'meal prep']
    },
    'reading': {
      participants: 400000000,
      patterns: ['reading', 'read', 'book', 'literature', 'study', 'studying']
    },
    'swimming': {
      participants: 300000000,
      patterns: ['swimming', 'swim', 'pool', 'lap swimming', 'water exercise', 'aquatic']
    },
    'cycling': {
      participants: 200000000,
      patterns: ['cycling', 'bike', 'biking', 'bicycle', 'bike riding', 'pedaling']
    },
    'running': {
      participants: 150000000,
      patterns: ['running', 'run', 'jogging', 'jog', 'sprint', 'marathon', 'distance running']
    },
    
    // High participation (10-100 million participants)
    'basketball': {
      participants: 100000000,
      patterns: ['basketball', 'hoops', 'court', 'dribbling', 'shooting hoops']
    },
    'soccer': {
      participants: 80000000,
      patterns: ['soccer', 'football', 'futbol', 'association football', 'kick ball']
    },
    'tennis': {
      participants: 60000000,
      patterns: ['tennis', 'racquet', 'court tennis', 'singles', 'doubles']
    },
    'golf': {
      participants: 50000000,
      patterns: ['golf', 'golfing', 'course', 'putting', 'driving range', 'tee']
    },
    'yoga': {
      participants: 30000000,
      patterns: ['yoga', 'meditation', 'mindfulness', 'stretching', 'poses', 'asana']
    },
    'weightlifting': {
      participants: 25000000,
      patterns: ['weightlifting', 'weight lifting', 'gym', 'strength training', 'bodybuilding', 'lifting']
    },
    'skiing': {
      participants: 20000000,
      patterns: ['skiing', 'ski', 'downhill', 'alpine skiing', 'cross country', 'snow skiing']
    },
    'surfing': {
      participants: 15000000,
      patterns: ['surfing', 'surf', 'wave riding', 'board riding', 'surfboard']
    },
    'martial arts': {
      participants: 12000000,
      patterns: ['martial arts', 'karate', 'judo', 'taekwondo', 'kung fu', 'self defense']
    },
    'boxing': {
      participants: 10000000,
      patterns: ['boxing', 'box', 'pugilism', 'sparring', 'punching']
    },
    
    // Moderate participation (1-10 million) - still mainstream
    'snowboarding': {
      participants: 8000000,
      patterns: ['snowboarding', 'snowboard', 'snow boarding', 'board']
    },
    'motorcycling': {
      participants: 5000000,
      patterns: ['motorcycle', 'motorbike', 'bike racing', 'motorcycle riding', 'motor bike']
    },
    'sailing': {
      participants: 4000000,
      patterns: ['sailing', 'sail', 'boat', 'yacht', 'vessel', 'maritime']
    },
    'kayaking': {
      participants: 3000000,
      patterns: ['kayaking', 'kayak', 'paddling', 'canoe', 'canoeing']
    },
    'rock climbing': {
      participants: 2000000,
      patterns: ['rock climbing', 'climbing', 'bouldering', 'indoor climbing', 'sport climbing']
    },
    'horseback riding': {
      participants: 1500000,
      patterns: ['horseback riding', 'horse riding', 'equestrian', 'riding']
    },
    
    // Low participation (<1 million) - not mainstream
    'ice climbing': {
      participants: 100000,
      patterns: ['ice climbing', 'ice axe', 'frozen waterfall', 'ice wall']
    },
    'skydiving': {
      participants: 300000,
      patterns: ['skydiving', 'skydive', 'parachuting', 'parachute', 'freefall']
    },
    'bungee jumping': {
      participants: 200000,
      patterns: ['bungee jumping', 'bungee', 'elastic cord jumping', 'bridge jump']
    },
    'free climbing': {
      participants: 50000,
      patterns: ['free climbing', 'free solo', 'free solo climbing', 'solo climbing']
    },
    'base jumping': {
      participants: 5000,
      patterns: ['base jumping', 'base jump', 'cliff jumping', 'bridge jumping']
    },
    'wingsuit flying': {
      participants: 2000,
      patterns: ['wingsuit flying', 'wingsuit', 'wing suit', 'flying squirrel', 'proximity flying']
    }
  };

  const activityLower = activity.toLowerCase().trim();
  
  // Enhanced pattern matching - prioritize exact matches first
  for (const [activityName, data] of Object.entries(mainstreamActivities)) {
    // Check for exact pattern matches first
    for (const pattern of data.patterns) {
      if (activityLower === pattern || activityLower.split(/\s+/).includes(pattern)) {
        return data.participants >= 1000000; // 1 million+ participants = mainstream
      }
    }
  }
  
  // Then check for partial matches
  for (const [activityName, data] of Object.entries(mainstreamActivities)) {
    for (const pattern of data.patterns) {
      if (activityLower.includes(pattern)) {
        return data.participants >= 1000000;
      }
    }
  }
  
  // Enhanced category-based detection for unknown activities
  const mainstreamCategories = [
    'sport', 'game', 'exercise', 'fitness', 'workout', 'training',
    'daily', 'routine', 'household', 'chore', 'work', 'job',
    'travel', 'commute', 'transport', 'education', 'school',
    'hobby', 'craft', 'art', 'music', 'entertainment'
  ];
  
  const nonMainstreamKeywords = [
    'extreme', 'dangerous', 'risky', 'amateur', 'professional',
    'advanced', 'expert', 'competitive', 'championship',
    'experimental', 'untested', 'diy', 'homemade'
  ];
  
  // Check for mainstream category indicators
  const hasMainstreamIndicators = mainstreamCategories.some(cat => 
    activityLower.includes(cat)
  );
  
  // Check for non-mainstream indicators
  const hasNonMainstreamIndicators = nonMainstreamKeywords.some(keyword => 
    activityLower.includes(keyword)
  );
  
  if (hasNonMainstreamIndicators) {
    return false;
  }
  
  if (hasMainstreamIndicators) {
    return true;
  }
  
  // Default to mainstream for completely unknown activities (conservative approach)
  return true;
}

function convertTo100ScaleWithCurve(score10: number, activity: string): number {
  if (!score10 || isNaN(score10)) {
    return 15;
  }

  score10 = Math.max(0.5, Math.min(10, score10));
  const isMainstream = isMainstreamActivity(activity);
  const isCriminalActivity = score10 <= 4.0;

  let score100;

  if (isMainstream) {
    // Apply curve for mainstream activities
    const normalized = (score10 - 0.5) / 9.5;
    
    if (isCriminalActivity) {
      const curved = Math.pow(normalized, 1.5);
      score100 = 2 + (curved * 40);
    } else {
      const curved = Math.pow(normalized, 0.7);
      score100 = 15 + (curved * 80);
    }
  } else {
    // Linear scaling for non-mainstream activities (no curve)
    if (isCriminalActivity) {
      score100 = 2 + ((score10 - 0.5) / 3.5) * 40; // Linear scale from 2-42
    } else {
      score100 = ((score10 - 0.5) / 9.5) * 95 + 2.5; // Linear scale from 2.5-97.5
    }
  }

  const variance = (Math.random() - 0.5) * 1.5;
  const finalScore = score100 + variance;

  return Math.max(2, Math.min(95, Math.round(finalScore)));
}

function extractScoreFromResponse(text: string): number | null {
  if (!text) return null;

  const patterns = [
    /(\d+\.?\d*)\s*\/\s*10/,
    /score:?\s*(\d+\.?\d*)/i,
    /rating:?\s*(\d+\.?\d*)/i,
    /(\d+\.?\d*)\s*out\s*of\s*10/i,
    /^(\d+\.?\d*)$/
  ];

  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match) {
      const score = parseFloat(match[1]);
      if (score >= 1 && score <= 10) return score;
    }
  }

  return null;
}

// Enhanced activity parsing and classification system
interface ActivityAnalysis {
  baseActivity: string;
  modifiers: string[];
  context: string[];
  riskFactors: string[];
  category: string;
  baseScore: number;
}

function parseActivity(activity: string): ActivityAnalysis {
  const activityLower = activity.toLowerCase().trim();
  
  // Extract modifiers that change risk level
  const riskModifiers = {
    extreme: ['extreme', 'amateur', 'untrained', 'without safety', 'first time', 'solo', 'unguided', 'diy', 'homemade'],
    safer: ['professional', 'supervised', 'with instructor', 'certified', 'licensed', 'indoor', 'controlled'],
    location: ['high altitude', 'underwater', 'in storm', 'at night', 'in winter', 'remote area', 'urban', 'highway'],
    equipment: ['without helmet', 'no safety gear', 'faulty equipment', 'proper equipment', 'safety certified']
  };

  const foundModifiers: string[] = [];
  const foundContext: string[] = [];
  const foundRiskFactors: string[] = [];

  // Extract modifiers
  Object.entries(riskModifiers).forEach(([type, modifiers]) => {
    modifiers.forEach(modifier => {
      if (activityLower.includes(modifier)) {
        foundModifiers.push(modifier);
        if (type === 'extreme') foundRiskFactors.push('high_risk_modifier');
        if (type === 'safer') foundRiskFactors.push('safety_modifier');
        if (type === 'location') foundContext.push(modifier);
        if (type === 'equipment') foundRiskFactors.push('equipment_factor');
      }
    });
  });

  // Identify base activity through comprehensive matching
  const baseActivity = identifyBaseActivity(activityLower);
  const category = categorizeActivity(baseActivity);
  const baseScore = getBaseActivityScore(baseActivity, category);

  return {
    baseActivity,
    modifiers: foundModifiers,
    context: foundContext,
    riskFactors: foundRiskFactors,
    category,
    baseScore
  };
}

function identifyBaseActivity(activityLower: string): string {
  // Comprehensive activity database with synonyms and variations
  const activityPatterns = {
    // Transportation
    'driving': ['driving', 'drive', 'car', 'automobile', 'vehicle operation'],
    'flying': ['flying', 'pilot', 'aviation', 'aircraft', 'airplane', 'plane'],
    'cycling': ['cycling', 'biking', 'bicycle', 'bike riding', 'mountain biking'],
    'motorcycling': ['motorcycle', 'motorbike', 'bike racing', 'motorcycle riding'],
    
    // Extreme sports (check these first to avoid conflicts)
    'skydiving': ['skydiving', 'skydive', 'parachuting', 'parachute', 'freefall'],
    'base jumping': ['base jumping', 'base jump', 'cliff jumping', 'bridge jumping'],
    'bungee jumping': ['bungee jumping', 'bungee', 'elastic cord jumping', 'bridge jump'],
    'wingsuit flying': ['wingsuit flying', 'wingsuit', 'wing suit', 'flying squirrel', 'proximity flying'],
    'free climbing': ['free climbing', 'free solo climbing', 'rock climbing', 'cliff climbing'],
    
    // Water activities
    'swimming': ['swimming', 'swim', 'pool', 'lap swimming', 'water exercise'],
    'surfing': ['surfing', 'surf', 'wave riding', 'board riding'],
    'diving': ['scuba diving', 'deep diving', 'cave diving', 'underwater diving'],
    'kayaking': ['kayaking', 'kayak', 'paddling', 'canoe', 'rafting'],
    'sailing': ['sailing', 'boat', 'yacht', 'vessel', 'maritime'],
    
    // Winter sports
    'skiing': ['skiing', 'ski', 'downhill', 'alpine skiing', 'cross country'],
    'snowboarding': ['snowboarding', 'snowboard', 'snow boarding', 'board'],
    'ice climbing': ['ice climbing', 'ice axe', 'frozen waterfall', 'ice wall'],
    
    // Combat sports
    'boxing': ['boxing', 'box', 'pugilism', 'prizefighting', 'sparring'],
    'martial arts': ['martial arts', 'karate', 'judo', 'taekwondo', 'kung fu', 'mma'],
    'wrestling': ['wrestling', 'grappling', 'takedown', 'submission'],
    
    // Team sports
    'football': ['football', 'american football', 'tackle', 'gridiron'],
    'soccer': ['soccer', 'football', 'futbol', 'association football'],
    'basketball': ['basketball', 'hoops', 'court', 'dribbling'],
    'hockey': ['hockey', 'ice hockey', 'puck', 'stick'],
    
    // Individual sports
    'tennis': ['tennis', 'racquet', 'court tennis', 'singles', 'doubles'],
    'golf': ['golf', 'golfing', 'course', 'putting', 'driving range'],
    'running': ['running', 'jogging', 'sprint', 'marathon', 'track'],
    'gymnastics': ['gymnastics', 'tumbling', 'vault', 'beam', 'floor exercise'],
    
    // Outdoor activities
    'hiking': ['hiking', 'trekking', 'trail', 'backpacking', 'mountain climbing'],
    'camping': ['camping', 'camp', 'outdoor', 'wilderness', 'tent'],
    'hunting': ['hunting', 'hunt', 'game', 'rifle', 'bow hunting'],
    'fishing': ['fishing', 'angling', 'catch', 'rod', 'reel'],
    
    // Daily activities
    'cooking': ['cooking', 'baking', 'kitchen', 'culinary', 'food preparation'],
    'cleaning': ['cleaning', 'housework', 'chores', 'tidying', 'organizing'],
    'gardening': ['gardening', 'planting', 'yard work', 'landscaping', 'horticulture'],
    'shopping': ['shopping', 'retail', 'mall', 'store', 'purchasing'],
    
    // Fitness/wellness
    'yoga': ['yoga', 'meditation', 'mindfulness', 'stretching', 'poses'],
    'weightlifting': ['weightlifting', 'gym', 'strength training', 'bodybuilding'],
    'walking': ['walking', 'stroll', 'pedestrian', 'walk', 'ramble'],
    
    // Mental activities
    'reading': ['reading', 'book', 'literature', 'study', 'learning'],
    'chess': ['chess', 'board game', 'strategy game', 'intellectual game'],
    'video games': ['gaming', 'video games', 'computer games', 'console'],
    
    // Creative activities
    'painting': ['painting', 'art', 'drawing', 'sketching', 'artistic'],
    'music': ['music', 'instrument', 'singing', 'performing', 'concert'],
    'writing': ['writing', 'authoring', 'journalism', 'creative writing']
  };

  // Find best match for base activity - prioritize exact matches first
  for (const [activity, patterns] of Object.entries(activityPatterns)) {
    for (const pattern of patterns) {
      // Check for exact word matches first
      const words = activityLower.split(/\s+/);
      if (words.includes(pattern) || pattern === activityLower) {
        return activity;
      }
    }
  }
  
  // If no exact match, check for partial matches
  for (const [activity, patterns] of Object.entries(activityPatterns)) {
    for (const pattern of patterns) {
      if (activityLower.includes(pattern)) {
        return activity;
      }
    }
  }

  // If no specific match, try to categorize by keywords
  if (activityLower.includes('sport') || activityLower.includes('game')) return 'general_sport';
  if (activityLower.includes('work') || activityLower.includes('job')) return 'work_activity';
  if (activityLower.includes('travel') || activityLower.includes('vacation')) return 'travel';
  
  return 'unknown_activity';
}

function categorizeActivity(baseActivity: string): string {
  const categories = {
    'extreme_sports': ['skydiving', 'base jumping', 'bungee jumping', 'wingsuit flying', 'free climbing'],
    'water_sports': ['swimming', 'surfing', 'diving', 'kayaking', 'sailing'],
    'winter_sports': ['skiing', 'snowboarding', 'ice climbing'],
    'combat_sports': ['boxing', 'martial arts', 'wrestling'],
    'team_sports': ['football', 'soccer', 'basketball', 'hockey'],
    'individual_sports': ['tennis', 'golf', 'running', 'gymnastics'],
    'outdoor_activities': ['hiking', 'camping', 'hunting', 'fishing'],
    'transportation': ['driving', 'flying', 'cycling', 'motorcycling'],
    'daily_activities': ['cooking', 'cleaning', 'gardening', 'shopping'],
    'fitness_wellness': ['yoga', 'weightlifting', 'walking'],
    'mental_activities': ['reading', 'chess', 'video games'],
    'creative_activities': ['painting', 'music', 'writing']
  };

  for (const [category, activities] of Object.entries(categories)) {
    if (activities.includes(baseActivity)) {
      return category;
    }
  }
  
  return 'general';
}

function getBaseActivityScore(baseActivity: string, category: string): number {
  // Refined scoring based on statistical injury/fatality data
  const activityScores = {
    // Extreme sports (0.5-2.5) - Based on fatality rates per participant
    'base jumping': 0.6,      // 1 in 2,300 participants
    'wingsuit flying': 0.5,   // 1 in 900 participants  
    'free climbing': 0.8,     // 1 in 320,000 climbs
    'skydiving': 2.2,         // 1 in 100,000 jumps
    'bungee jumping': 2.5,    // 1 in 500,000 jumps
    
    // High-risk sports (2.5-4.5)
    'diving': 3.2,            // Decompression/drowning risks
    'motorcycling': 2.8,      // 27x more dangerous than cars
    'flying': 3.5,            // General aviation accidents
    'ice climbing': 3.0,      // Equipment failure/weather
    
    // Moderate-high risk (4.5-6.5)
    'skiing': 5.2,            // 0.5 injuries per 1000 skier days
    'snowboarding': 4.8,      // Higher injury rate than skiing
    'surfing': 5.5,           // Drowning, sharks, injuries
    'horseback riding': 4.5,  // Falls and kicks
    'boxing': 4.2,            // Concussion risks
    'football': 4.0,          // CTE and injury rates
    
    // Moderate risk (6.5-7.5)
    'driving': 6.8,           // Motor vehicle statistics
    'cycling': 6.5,           // Traffic and fall risks
    'swimming': 7.2,          // Drowning statistics
    'hiking': 7.0,            // Weather/terrain risks
    'basketball': 7.1,        // Contact injuries
    'soccer': 6.9,            // Concussion/contact
    'hockey': 6.2,            // High-speed collisions
    
    // Low-moderate risk (7.5-8.5)
    'tennis': 8.2,            // Low injury rates
    'running': 7.8,           // Overuse injuries
    'golf': 8.5,              // Very low serious injury
    'volleyball': 8.0,        // Moderate contact
    'walking': 8.3,           // Minimal risks
    'weightlifting': 7.6,     // Form-dependent
    
    // Low risk (8.5-10.0)
    'yoga': 9.2,              // Very safe with instruction
    'reading': 9.9,           // Virtually no physical risk
    'chess': 9.8,             // Mental activity only
    'cooking': 8.7,           // Burns, cuts possible
    'gardening': 8.9,         // Minor tool injuries
    'painting': 9.5,          // Minimal physical risk
    'writing': 9.7,           // Repetitive strain only
    
    // Work/general activities
    'work_activity': 7.5,     // Varies by occupation
    'general_sport': 6.5,     // Average sport risk
    'travel': 7.8,            // Transportation risks
    'unknown_activity': 6.0   // Conservative estimate
  };

  return activityScores[baseActivity as keyof typeof activityScores] || 6.0;
}

function calculateIntelligentScore(activity: string): number {
  const analysis = parseActivity(activity);
  let score = analysis.baseScore;
  
  // Apply modifier adjustments
  analysis.riskFactors.forEach(factor => {
    switch (factor) {
      case 'high_risk_modifier':
        score = Math.max(0.5, score - 2.5); // Significant risk increase
        break;
      case 'safety_modifier':
        score = Math.min(9.5, score + 1.5); // Safety improvement
        break;
      case 'equipment_factor':
        // Equipment issues reduce safety significantly
        if (analysis.modifiers.some(m => m.includes('without') || m.includes('faulty'))) {
          score = Math.max(0.5, score - 2.0);
        }
        break;
    }
  });
  
  // Apply context adjustments
  analysis.context.forEach(context => {
    if (['high altitude', 'underwater', 'in storm', 'at night', 'remote area'].includes(context)) {
      score = Math.max(0.5, score - 1.5);
    }
    if (['indoor', 'controlled', 'urban'].includes(context)) {
      score = Math.min(9.5, score + 0.5);
    }
  });
  
  // Add small random variance for realism
  score += (Math.random() - 0.5) * 0.4;
  
  return Math.max(0.5, Math.min(10, score));
}

function applyDangerLogic(activity: string, initialScore: number): number {
  const activityLower = activity.toLowerCase().trim();

  const criticalDangers = [
    'diy rocket', 'homemade explosive', 'amateur surgery', 'untrained pilot',
    'nuclear', 'radioactive', 'toxic chemical', 'asbestos work'
  ];

  const extremeModifiers = [
    'without education', 'without license', 'amateur', 'diy', 'homemade',
    'untested', 'experimental', 'first time'
  ];

  const highRiskContexts = [
    'high altitude', 'underwater', 'extreme weather', 'active volcano',
    'war zone', 'combat area'
  ];

  let dangerScore = initialScore;

  for (const danger of criticalDangers) {
    if (activityLower.includes(danger)) {
      dangerScore = Math.min(dangerScore, 1.0);
      break;
    }
  }

  let modifierCount = 0;
  for (const modifier of extremeModifiers) {
    if (activityLower.includes(modifier)) modifierCount++;
  }
  if (modifierCount > 0) {
    dangerScore = Math.max(0.5, dangerScore - (modifierCount * 1.5));
  }

  let contextCount = 0;
  for (const context of highRiskContexts) {
    if (activityLower.includes(context)) contextCount++;
  }
  if (contextCount > 0) {
    dangerScore = Math.max(0.5, dangerScore - (contextCount * 1.0));
  }

  return Math.max(0.5, Math.min(10, dangerScore));
}

function calculateIntelligentWhaleGrade(activity: string): WhaleGradeResult {
  const score10 = calculateIntelligentScore(activity);
  const adjustedScore10 = applyDangerLogic(activity, score10);
  const score100 = convertTo100ScaleWithCurve(adjustedScore10, activity);

  let safetyRating: "Safe" | "Moderate Safe" | "Less Safe" | "Dangerous" | "Extremely Dangerous";
  if (score100 >= 75) safetyRating = "Safe";
  else if (score100 >= 55) safetyRating = "Moderate Safe";
  else if (score100 >= 35) safetyRating = "Less Safe";
  else if (score100 >= 20) safetyRating = "Dangerous";
  else safetyRating = "Extremely Dangerous";

  const explanation = generateActivitySpecificExplanation(activity, score100, safetyRating);

  return {
    score: Math.round(score100),
    safetyRating,
    explanation
  };
}