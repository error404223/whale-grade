import { pgTable, text, serial, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  activityName: text("activity_name").notNull(),
  whaleGrade: real("whale_grade").notNull(), // Now stores 0-100 scale
  safetyRating: text("safety_rating").notNull(),
  explanation: text("explanation").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

// API request/response schemas
export const assessActivitySchema = z.object({
  activity: z.string()
    .min(1, "Activity name is required")
    .max(200, "Activity name too long")
    .refine((val) => {
      // Content filtering - block inappropriate content
      const inappropriate = [
        'suicide', 'self-harm', 'murder', 'killing', 'terrorist', 'bomb',
        'genocide', 'torture', 'rape', 'abuse', 'trafficking', 'slavery'
      ];
      const lowerVal = val.toLowerCase();
      return !inappropriate.some(term => lowerVal.includes(term));
    }, "Please enter a legitimate activity")
    .refine((val) => {
      // Block spam patterns
      const spamPatterns = [
        /(.)\1{10,}/, // Repeated characters
        /^\s*$/, // Only whitespace
        /^[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]*$/ // Only special characters
      ];
      return !spamPatterns.some(pattern => pattern.test(val));
    }, "Please enter a valid activity name")
    .refine((val) => {
      // Require actual words
      const words = val.trim().split(/\s+/).filter(word => word.length > 0);
      return words.length > 0 && words.some(word => /^[a-zA-Z]/.test(word));
    }, "Please enter a real activity"),
});

export const whaleGradeResponseSchema = z.object({
  score: z.number().min(0).max(100),
  safetyRating: z.enum(["safe", "Moderate Safe", "Less Safe", "Dangerous", "Extremely Dangerous"]),
  explanation: z.string(),
  activityName: z.string(),
});

export type AssessActivityRequest = z.infer<typeof assessActivitySchema>;
export type WhaleGradeResponse = z.infer<typeof whaleGradeResponseSchema>;
