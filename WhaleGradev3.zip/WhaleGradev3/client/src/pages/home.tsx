import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Search, Loader2 } from "lucide-react";
import type { WhaleGradeResponse, AssessActivityRequest } from "@shared/schema";

const safetyConfigs = {
  'Safe': {
    color: 'bg-green-500',
    emoji: '🟢',
    textColor: 'text-green-600',
    bgLight: 'bg-green-50'
  },
  'Moderate Safe': {
    color: 'bg-yellow-500',
    emoji: '🟡', 
    textColor: 'text-yellow-600',
    bgLight: 'bg-yellow-50'
  },
  'Less Safe': {
    color: 'bg-orange-500',
    emoji: '🟠',
    textColor: 'text-orange-600',
    bgLight: 'bg-orange-50'
  },
  'Dangerous': {
    color: 'bg-red-500',
    emoji: '🔴',
    textColor: 'text-red-600',
    bgLight: 'bg-red-50'
  },
  'Extremely Dangerous': {
    color: 'bg-red-900',
    emoji: '⚠️',
    textColor: 'text-red-900',
    bgLight: 'bg-red-100'
  }
};

const exampleActivities = [
  { name: "skydiving", emoji: "🪂" },
  { name: "driving", emoji: "🚗" },
  { name: "cooking", emoji: "👨‍🍳" },
  { name: "mountain climbing", emoji: "🏔️" },
];

export default function Home() {
  const [activity, setActivity] = useState("");
  const [result, setResult] = useState<WhaleGradeResponse | null>(null);
  const { toast } = useToast();

  // Added state for modal
  const [isModalOpen, setModalOpen] = useState(false);
  const [modalType, setModalType] = useState<'risk' | 'safety' | 'whale' | 'ai' | null>(null);

  const assessMutation = useMutation({
    mutationFn: async (data: AssessActivityRequest) => {
      const response = await apiRequest("POST", "/api/assess-activity", data);
      return response.json() as Promise<WhaleGradeResponse>;
    },
    onSuccess: (data) => {
      setResult(data);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to assess activity. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activity.trim()) return;

    assessMutation.mutate({ activity: activity.trim() });
  };

  const handleExampleClick = (exampleActivity: string) => {
    setActivity(exampleActivity);
    assessMutation.mutate({ activity: exampleActivity });
  };

  const resetForm = () => {
    setActivity("");
    setResult(null);
  };

  const config = result ? safetyConfigs[result.safetyRating] : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 font-inter">
      {/* Header */}
      <header className="w-full py-6 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <motion.h1 
            className="text-4xl md:text-5xl font-bold text-blue-800 mb-2"
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            🐋 Whale Grade
          </motion.h1>
          <motion.p 
            className="text-lg text-slate-600 font-medium"
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Discover the safety score of any activity
                    </motion.p>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 pb-12">
        {/* Input Section */}
        <motion.section 
          className="mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
        >
          <Card className="shadow-lg border-0">
            <CardContent className="p-8 md:p-12">
              <div className="text-center mb-8">
                <h2 className="text-2xl md:text-3xl font-semibold text-slate-800 mb-4">
                  What activity would you like to assess?
                </h2>
                <p className="text-slate-600 text-lg">
                  Enter any activity from everyday tasks to extreme adventures
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="relative">
                  <Input
                    type="text"
                    value={activity}
                    onChange={(e) => setActivity(e.target.value)}
                    placeholder="e.g., surfing, walking, skydiving, cooking..."
                    className="text-lg py-6 pr-12 border-2 focus:border-blue-500 focus:ring-4 focus:ring-blue-50"
                    disabled={assessMutation.isPending}
                    required
                  />
                  <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-6 h-6" />
                </div>

                <Button
                  type="submit"
                  disabled={assessMutation.isPending || !activity.trim()}
                  className="w-full bg-blue-700 hover:bg-blue-800 text-white font-semibold py-6 text-lg transition-all duration-300 transform hover:scale-[1.02] active:scale-[0.98]"
                >
                  {assessMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Analyzing Activity...
                    </>
                  ) : (
                    "Get Whale Grade"
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>
        </motion.section>

        {/* Results Section */}
        <AnimatePresence>
          {result && (
            <motion.section
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -40 }}
              transition={{ duration: 0.6 }}
            >
              <Card className="shadow-lg border-0">
                <CardContent className="p-8 md:p-12">
                  {/* Score Display */}
                  <div className="text-center mb-8">
                    <motion.div
                      className={`inline-flex items-center justify-center w-32 h-32 rounded-full mb-6 ${config?.color}`}
                      initial={{ scale: 0.8, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      transition={{ duration: 0.8, type: "spring", bounce: 0.4 }}
                    >
                      <span className="text-4xl font-bold text-white">
                        {result.score}/100
                      </span>
                    </motion.div>

                    <motion.h3 
                      className="text-3xl font-bold mb-2 capitalize"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      {result.activityName}
                    </motion.h3>

                    <motion.div 
                      className={`inline-flex items-center px-6 py-3 rounded-full text-lg font-semibold ${config?.textColor} ${config?.bgLight}`}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.4 }}
                    >
                      <span className="mr-2">{config?.emoji}</span>
                      <span>{result.safetyRating}</span>
                    </motion.div>
                  </div>

                  {/*Analysis Button */}
                  <motion.div 
                    className="mb-8"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.5 }}
                  >
                    <button 
                      onClick={() => { setModalType('ai'); setModalOpen(true); }}
                      className="w-full bg-gradient-to-br from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 rounded-xl p-6 transition-all duration-300 transform hover:scale-[1.02] text-left border border-blue-100"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <span className="text-2xl mr-3">🤖</span>
                          <div>
                            <h4 className="text-lg font-semibold text-blue-800 mb-1">
                              
                    Analysis
                            </h4>
                            <p className="text-sm text-blue-600">
                              Get detailed insights on your safety score and improvement tips
                            </p>
                          </div>
                        </div>
                        <div className="text-blue-500 text-sm font-medium">
                          Click to view →
                        </div>
                      </div>
                    </button>
                  </motion.div>

                  {/* Safety Metrics Breakdown */}
                  <motion.div 
                    className="grid md:grid-cols-3 gap-6 mb-8"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6 }}
                  >
                    <button 
                      onClick={() => { setModalType('risk'); setModalOpen(true); }}
                      className="bg-gradient-to-br from-blue-50 to-blue-100 hover:from-blue-100 hover:to-blue-200 rounded-xl p-6 transition-all duration-300 transform hover:scale-105 text-left"
                    >
                      <div className="text-center mb-3">
                        <div className="text-2xl mb-2">⚡</div>
                        <h5 className="font-semibold text-slate-800 mb-1">Risk Assessment</h5>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Category:</span>
                          <span className="font-medium text-slate-800">{result.safetyRating}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Score:</span>
                          <span className="font-medium text-slate-800">{result.score}/100</span>
                        </div>
                        <div className="text-xs text-slate-500 mt-2 text-center">
                          Click for detailed breakdown
                        </div>
                      </div>
                    </button>

                    <button 
                      onClick={() => { setModalType('safety'); setModalOpen(true); }}
                      className="bg-gradient-to-br from-green-50 to-green-100 hover:from-green-100 hover:to-green-200 rounded-xl p-6 transition-all duration-300 transform hover:scale-105 text-left"
                    >
                      <div className="text-center mb-3">
                        <div className="text-2xl mb-2">🛡️</div>
                        <h5 className="font-semibold text-slate-800 mb-1">Safety Factors</h5>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Legal Status:</span>
                          <span className="font-medium text-slate-800">
                            {(() => {
                              const activityLower = result.activityName.toLowerCase();
                              const allIllegalActivities = [
                                // Violent felonies and life-threatening crimes
                                'murder', 'killing', 'homicide', 'manslaughter', 'suicide', 'drowning', 'suffocation', 'hanging',
                                'rape', 'sexual assault', 'sexual abuse', 'child abuse', 'child molestation',
                                'kidnapping', 'abduction', 'human trafficking', 'false imprisonment',
                                'aggravated assault', 'assault with weapon', 'assault with deadly weapon',
                                'armed robbery', 'bank robbery', 'carjacking',
                                'arson', 'bombing', 'terrorism', 'terrorist attack', 'explosive device',
                                'vehicular manslaughter', 'vehicular homicide', 'hit and run fatal',
                                // Serious felonies with potential for harm
                                'drug trafficking', 'drug distribution', 'drug dealing major', 'selling hard drugs',
                                'robbery', 'burglary', 'breaking and entering', 'home invasion',
                                'assault', 'battery', 'domestic violence', 'aggravated battery',
                                'drunk driving', 'dui', 'dwi', 'driving under influence', 'reckless driving',
                                'illegal street racing', 'street racing', 'reckless endangerment',
                                'extortion', 'blackmail', 'bribery major', 'corruption major',
                                'weapons trafficking', 'illegal weapons dealing', 'gun trafficking',
                                'money laundering major', 'embezzlement major', 'securities fraud major',
                                'animal cruelty severe', 'animal abuse severe', 'animal torture',
                                // Moderate crimes with some danger potential
                                'theft', 'stealing', 'larceny', 'shoplifting major', 'fraud', 'identity theft',
                                'credit card fraud', 'wire fraud', 'tax evasion', 'embezzlement',
                                'forgery', 'counterfeiting', 'check fraud',
                                'vandalism major', 'destruction of property', 'criminal mischief major',
                                'stalking', 'harassment', 'cyberstalking', 'cyberbullying severe',
                                'drug dealing', 'selling drugs', 'drug possession with intent',
                                'illegal gambling major', 'bookmaking', 'running illegal casino',
                                'unlawful possession weapon', 'concealed weapon violation',
                                'conspiracy major', 'obstruction of justice', 'perjury major',
                                // Minor crimes and infractions
                                'trespassing', 'criminal trespass', 'unlawful entry', 'loitering',
                                'shoplifting', 'petty theft', 'shoplifting minor',
                                'vandalism', 'graffiti', 'criminal mischief minor',
                                'disorderly conduct', 'public intoxication', 'disturbing the peace',
                                'minor drug possession', 'marijuana possession', 'drug paraphernalia',
                                'prostitution', 'soliciting prostitution', 'escort services',
                                'illegal gambling minor', 'illegal betting', 'underground poker',
                                'minor fraud', 'bounced check', 'fare evasion',
                                'traffic violations', 'speeding major', 'driving without license',
                                'cyberbullying minor', 'harassment minor', 'spam',
                                'contempt of court minor', 'failure to appear', 'probation violation minor'
                              ];
                              return allIllegalActivities.some(illegal => activityLower.includes(illegal)) ? 'Illegal' : 'Legal';
                            })()}
                          </span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Injury Rate:</span>
                          <span className="font-medium text-slate-800">
                            {result.score >= 75 ? 'Very Low' : 
                             result.score >= 55 ? 'Low' : 
                             result.score >= 35 ? 'Moderate' : 
                             result.score >= 20 ? 'High' : 'Very High'}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 mt-2 text-center">
                          Click for safety analysis
                        </div>
                      </div>
                    </button>

                    <button 
                      onClick={() => { setModalType('whale'); setModalOpen(true); }}
                      className="bg-gradient-to-br from-purple-50 to-purple-100 hover:from-purple-100 hover:to-purple-200 rounded-xl p-6 transition-all duration-300 transform hover:scale-105 text-left"
                    >
                      <div className="text-center mb-3">
                        <div className="text-2xl mb-2">🐋</div>
                        <h5 className="font-semibold text-slate-800 mb-1">Whale Wisdom</h5>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-slate-600">Recommendation:</span>
                          <span className="font-medium text-slate-800">
                            {result.score >= 75 ? 'Proceed' : 
                             result.score >= 55 ? 'Use Caution' : 
                             result.score >= 35 ? 'High Caution' : 
                             result.score >= 20 ? 'Not Advised' : 'Avoid'}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 mt-2">
                          AI-powered insights combining marine intelligence with safety analysis
                        </div>
                        <div className="text-xs text-slate-500 mt-2 text-center">
                          Click for whale wisdom insights
                        </div>
                      </div>
                    </button>
                  </motion.div>

                  {/* Action Buttons */}
                  <motion.div 
                    className="flex flex-col sm:flex-row gap-4 justify-center"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.7 }}
                  >
                    <Button
                      onClick={resetForm}
                      variant="outline"
                      className="py-3 px-6 font-medium"
                    >
                      Assess Another Activity
                    </Button>
                    <Button
                      onClick={() => {
                        navigator.share?.({
                          title: `Whale Grade: ${result.activityName}`,
                          text: `${result.activityName} received a Whale Grade of ${result.score}/100 (${result.safetyRating})`,
                          url: window.location.href,
                        }).catch(() => {
                          navigator.clipboard.writeText(
                            `${result.activityName} received a Whale Grade of ${result.score}/100 (${result.safetyRating})`
                          );
                          toast({
                            title: "Copied to clipboard!",
                            description: "Result copied to clipboard for sharing.",
                          });
                        });
                      }}
                      className="bg-blue-700 hover:bg-blue-800 py-3 px-6 font-medium"
                    >
                      Share Result
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.section>
          )}
        </AnimatePresence>

        {/* Example Activities */}
        {!result && (
          <motion.section 
            className="mt-12"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <div className="text-center mb-8">
              <h3 className="text-2xl font-semibold text-slate-800 mb-4">Popular Activities</h3>
              <p className="text-slate-600">Click any activity to see its Whale Grade</p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {exampleActivities.map((example, index) => (
                <motion.button
                  key={example.name}
                  onClick={() => handleExampleClick(example.name)}
                  className="bg-white hover:bg-blue-50 border-2 border-slate-200 hover:border-blue-500 rounded-xl p-4 text-center transition-all duration-300 transform hover:scale-105"
                  disabled={assessMutation.isPending}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.9 + index * 0.1 }}
                >
                  <div className="text-2xl mb-2">{example.emoji}</div>
                  <span className="font-medium text-slate-700 capitalize">{example.name}</span>
                </motion.button>
              ))}
            </div>
          </motion.section>
        )}
      </main>

      {/* Footer */}
      <footer className="text-center py-8 px-4">
        <p className="text-slate-500">
          <span className="mr-2">🐋</span>
          Whale Grade uses AI-powered safety analysis and a touch of marine wisdom
        </p>
      </footer>

      {/* Modal */}
      <AnimatePresence>
        {isModalOpen && result && modalType && (
          <motion.div
            className="fixed top-0 left-0 w-full h-full bg-slate-900 bg-opacity-50 z-50 flex items-center justify-center"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
          >
            <motion.div
              className="bg-white rounded-xl shadow-lg max-w-2xl w-full max-h-[80vh] overflow-y-auto relative"
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.8 }}
              transition={{ duration: 0.3 }}
            >
              <div className="sticky top-0 bg-white z-10 p-6 pb-2 border-b">
                <h3 className="text-2xl font-semibold text-slate-800 pr-8">
                  {modalType === 'risk' ? 'Risk Assessment Details' :
                   modalType === 'safety' ? 'Safety Factors Analysis' :
                   modalType === 'whale' ? 'Whale Wisdom Recommendations' :
                   modalType === 'ai' ? 'Personalized AI Analysis' : ''}
                </h3>
                <button 
                  onClick={() => setModalOpen(false)} 
                  className="absolute top-4 right-4 w-8 h-8 bg-blue-600 hover:bg-blue-700 rounded-full flex items-center justify-center text-white font-bold text-lg transition-colors duration-200"
                >
                  ×
                </button>
              </div>

              <div className="p-6 pt-4">

              {modalType === 'risk' && (
                  <div className="space-y-4">
                    <p><strong>Category:</strong> {result.safetyRating}</p>
                    <p><strong>Score:</strong> {result.score}/100</p>
                    <p>
                      <strong>Score Range:</strong>
                      {result.score >= 75 ? '75-100' : 
                       result.score >= 55 ? '55-74' : 
                       result.score >= 35 ? '35-54' : 
                       result.score >= 20 ? '20-34' : '0-19'}
                    </p>
                    <p className="text-sm text-slate-600">
                      {result.score >= 75 ? 'Very low injury rates with minimal risk' : 
                       result.score >= 55 ? 'Low to moderate risk with manageable factors' : 
                       result.score >= 35 ? 'Elevated risk requiring safety measures' : 
                       result.score >= 20 ? 'High risk with significant injury potential' : 
                       'Extreme risk with severe consequences possible'}
                    </p>
                  </div>
                )}

                {modalType === 'safety' && (
                  <div className="space-y-4">
                    <p>
                      <strong>Legal Status:</strong>
                      {(() => {
                        const activityLower = result.activityName.toLowerCase();
                        const allIllegalActivities = [
                          // Violent felonies and life-threatening crimes
                          'murder', 'killing', 'homicide', 'manslaughter', 'suicide', 'drowning', 'suffocation', 'hanging',
                          'rape', 'sexual assault', 'sexual abuse', 'child abuse', 'child molestation',
                          'kidnapping', 'abduction', 'human trafficking', 'false imprisonment',
                          'aggravated assault', 'assault with weapon', 'assault with deadly weapon',
                          'armed robbery', 'bank robbery', 'carjacking',
                          'arson', 'bombing', 'terrorism', 'terrorist attack', 'explosive device',
                          'vehicular manslaughter', 'vehicular homicide', 'hit and run fatal',
                          // Serious felonies with potential for harm
                          'drug trafficking', 'drug distribution', 'drug dealing major', 'selling hard drugs',
                          'robbery', 'burglary', 'breaking and entering', 'home invasion',
                          'assault', 'battery', 'domestic violence', 'aggravated battery',
                          'drunk driving', 'dui', 'dwi', 'driving under influence', 'reckless driving',
                          'illegal street racing', 'street racing', 'reckless endangerment',
                          'extortion', 'blackmail', 'bribery major', 'corruption major',
                          'weapons trafficking', 'illegal weapons dealing', 'gun trafficking',
                          'money laundering major', 'embezzlement major', 'securities fraud major',
                          'animal cruelty severe', 'animal abuse severe', 'animal torture',
                          // Moderate crimes with some danger potential
                          'theft', 'stealing', 'larceny', 'shoplifting major', 'fraud', 'identity theft',
                          'credit card fraud', 'wire fraud', 'tax evasion', 'embezzlement',
                          'forgery', 'counterfeiting', 'check fraud',
                          'vandalism major', 'destruction of property', 'criminal mischief major',
                          'stalking', 'harassment', 'cyberstalking', 'cyberbullying severe',
                          'drug dealing', 'selling drugs', 'drug possession with intent',
                          'illegal gambling major', 'bookmaking', 'running illegal casino',
                          'unlawful possession weapon', 'concealed weapon violation',
                          'conspiracy major', 'obstruction of justice', 'perjury major',
                          // Minor crimes and infractions
                          'trespassing', 'criminal trespass', 'unlawful entry', 'loitering',
                          'shoplifting', 'petty theft', 'shoplifting minor',
                          'vandalism', 'graffiti', 'criminal mischief minor',
                          'disorderly conduct', 'public intoxication', 'disturbing the peace',
                          'minor drug possession', 'marijuana possession', 'drug paraphernalia',
                          'prostitution', 'soliciting prostitution', 'escort services',
                          'illegal gambling minor', 'illegal betting', 'underground poker',
                          'minor fraud', 'bounced check', 'fare evasion',
                          'traffic violations', 'speeding major', 'driving without license',
                          'cyberbullying minor', 'harassment minor', 'spam',
                          'contempt of court minor', 'failure to appear', 'probation violation minor'
                        ];
                        return allIllegalActivities.some(illegal => activityLower.includes(illegal)) ? 'Illegal' : 'Legal';
                      })()}
                    </p>
                    <p>
                      <strong>Injury Rate:</strong>
                      {result.score >= 75 ? 'Very Low' : 
                       result.score >= 55 ? 'Low' : 
                       result.score >= 35 ? 'Moderate' : 
                       result.score >= 20 ? 'High' : 'Very High'}
                    </p>
                    <p className="text-sm text-slate-600">Based on statistical analysis and safety records</p>
                  </div>
                )}

                {modalType === 'whale' && (
                  <div className="space-y-4">
                    <div className="bg-purple-50 rounded-lg p-4 mb-4">
                      <h4 className="font-semibold text-purple-800 mb-2">What is Whale Wisdom?</h4>
                      <p className="text-sm text-purple-700">
                        Whale Wisdom enhances our safety analysis with a unique marine intelligence factor. Our system 
                        calculates the probability of encountering whales during your activity and applies a special 
                        adjustment to your safety score. Activities with higher whale encounter potential receive a 
                        protective bonus, as the presence of these wise ocean guardians is considered a positive omen 
                        for safety and good fortune.
                      </p>
                    </div>
                    <p>
                      <strong>Recommendation:</strong>
                      <span className="ml-2">
                        {result.score >= 75 ? 'Proceed' : 
                         result.score >= 55 ? 'Use Caution' : 
                         result.score >= 35 ? 'High Caution' : 
                         result.score >= 20 ? 'Not Advised' : 'Avoid'}
                      </span>
                    </p>
                    <p className="text-sm text-slate-600">
                      {result.score >= 75 ? 'High whale encounter probability has blessed this activity with additional safety points. The marine guardians approve!' : 
                       result.score >= 55 ? 'Moderate whale presence detected - their protective influence provides some safety enhancement to your score.' : 
                       result.score >= 35 ? 'Limited whale encounter potential offers minimal protective bonus. Extra caution recommended.' : 
                       result.score >= 20 ? 'Low whale probability means little marine protection. The ocean spirits advise extreme care.' : 
                       'Zero whale encounter chance - no protective marine bonus available. Avoid these dangerous waters.'}
                    </p>
                  </div>
                )}

                {modalType === 'ai' && (
                  <div className="space-y-6">
                    <div className="bg-white rounded-lg p-4 border-l-4 border-blue-500">
                      <h5 className="font-semibold text-slate-800 mb-2">Why this score?</h5>
                      <p className="text-slate-700 leading-relaxed">
                        {(() => {
                          const activityName = result.activityName.toLowerCase();
                          const score = result.score;

                          if (score >= 85) {
                            return `I gave ${result.activityName} a high score of ${score}/100 because it has exceptionally low injury rates and minimal safety risks. The activity demonstrates excellent safety records with very few reported incidents per participant.`;
                          } else if (score >= 70) {
                            return `${result.activityName} received a ${score}/100 because while generally safe, there are some minor risk factors to consider. The injury rates are low but not negligible, with most incidents being minor and preventable.`;
                          } else if (score >= 55) {
                            return `I assigned ${score}/100 to ${result.activityName} due to moderate safety concerns. The activity has documented injury rates that require attention, though most can be mitigated with proper preparation and safety measures.`;
                          } else if (score >= 40) {
                            return `${result.activityName} scored ${score}/100 because of elevated risk factors and higher injury rates. The activity presents significant safety challenges that require serious consideration and comprehensive safety protocols.`;
                          } else if (score >= 20) {
                            return `The score of ${score}/100 reflects the high-risk nature of ${result.activityName}. This activity has substantial injury and fatality statistics that make it inherently dangerous, requiring expert-level preparation and acceptance of significant risk.`;
                          } else {
                            const activityLower = activityName;
                            const illegalActivities = [
                              'murder', 'killing', 'homicide', 'manslaughter', 'rape', 'sexual assault', 'kidnapping', 'terrorism',
                              'drug trafficking', 'robbery', 'burglary', 'drunk driving', 'weapons trafficking', 'theft', 'fraud'
                            ];
                            const isIllegal = illegalActivities.some(illegal => activityLower.includes(illegal));

                            if (isIllegal) {
                              return `${result.activityName} received an extremely low score of ${score}/100 because it involves illegal activities with severe legal consequences, combined with extremely high risk of harm. This represents both legal and physical danger.`;
                            } else {
                              return `The very low score of ${score}/100 for ${result.activityName} reflects extreme danger with exceptionally high injury and fatality rates. This activity poses life-threatening risks that are difficult to mitigate even with extensive preparation.`;
                            }
                          }
                        })()}
                      </p>
                    </div>

                    <div className="bg-white rounded-lg p-4 border-l-4 border-green-500">
                      <h5 className="font-semibold text-slate-800 mb-2">How to make it safer</h5>
                      <p className="text-slate-700 leading-relaxed">
                        {(() => {
                          const activityName = result.activityName.toLowerCase();
                          const score = result.score;

                          if (score >= 85) {
                            return `To maintain the high safety level of ${result.activityName}: follow standard safety guidelines, stay aware of your surroundings, use proper equipment if applicable, and don't become complacent. Even safe activities benefit from mindful practice.`;
                          } else if (score >= 70) {
                            return `Enhance safety for ${result.activityName} by: getting proper education, using appropriate safety equipment, choosing suitable weather and environmental conditions, and always having a safety plan or backup.`;
                          } else if (score >= 55) {
                            return `Improve safety for ${result.activityName} through: comprehensive education with certified educators, investing in high-quality safety gear, thoroughly understanding the risks involved, practicing in controlled environments first, and never participating alone.`;
                          } else if (score >= 40) {
                            return `To reduce risks in ${result.activityName}: seek professional education and certification, use only top-tier safety equipment, ensure medical support is available, have detailed emergency plans, consider your experience level honestly, and gradually build skills.`;
                          } else if (score >= 20) {
                            return `For high-risk ${result.activityName}: extensive professional education is essential, use certified equipment and guides, ensure comprehensive insurance coverage, have emergency medical plans, consider the impact on family/dependents, and honestly assess if the risks are worth it.`;
                          } else {
                            const activityLower = activityName;
                            const illegalActivities = [
                              'murder', 'killing', 'homicide', 'manslaughter', 'rape', 'sexual assault', 'kidnapping', 'terrorism',
                              'drug trafficking', 'robbery', 'burglary', 'drunk driving', 'weapons trafficking', 'theft', 'fraud'
                            ];
                            const isIllegal = illegalActivities.some(illegal => activityLower.includes(illegal));

                            if (isIllegal) {
                              return `The safest approach to ${result.activityName} is complete avoidance. Instead, consider legal alternatives, seek professional counseling if needed, understand the severe legal consequences, and focus on positive, constructive activities that don't harm others or yourself.`;
                            } else {
                              return `For extremely dangerous ${result.activityName}: the safest option is often not to participate. If you must proceed, work only with world-class experts, use the absolute best equipment available, have comprehensive medical support on standby, and ensure you fully understand the life-threatening nature of the risks.`;
                            }
                          }
                        })()}
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}